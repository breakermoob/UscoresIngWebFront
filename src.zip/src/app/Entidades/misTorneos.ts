export class MisTorneos {
	correo: String;	
	idTorneo: number;
}