export class Evento {
    id: number;
	nombre: String;
	lugar: String;
	torneo: number;	
	estado: String;
}