export class Favoritos {
	correo: String;
	evento: number;
}