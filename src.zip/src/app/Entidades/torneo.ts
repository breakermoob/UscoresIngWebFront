export class Torneo {
    id: number;
    nombre: String;
    deporte: String;  
    error: String = '.';
}