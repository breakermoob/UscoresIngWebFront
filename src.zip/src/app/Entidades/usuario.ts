export class Usuario {
	correo: String;
	nombre: String;
	contrasena: String;	
}